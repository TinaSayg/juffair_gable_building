<tr>
    <td>Name</td>
    <td>{{ isset($room->name) ? $room->name: '' }}</td>
</tr>


