@extends('layouts.admin.app')
{{-- Page title --}}

{{-- page level styles --}}
@section('header_styles')
<link rel="stylesheet" href="{{asset('public/admin/assets/bundles/bootstrap-daterangepicker/daterangepicker.css') }}">
<style>
   
</style>
@stop
@section('content')


<section class="section">
    {{-- <ul class="breadcrumb breadcrumb-style ">
       <li class="breadcrumb-item">
          <h4 class="page-title m-b-0">Create Utility Bill</h4>
       </li>
       <li class="breadcrumb-item">
          <a href="file:///F:/AMS/tenantlist.html">
          <i class="fas fa-home"></i></a>
       </li>
    </ul> --}}
    <div class="section-body">
    <div class="row">
    <div class="col-12" >
        <div class="card">
            <div class="card-header">
              <h4>Edit Service Contract Form</h4>
            </div>
            <div class="card-body">
            <form method="POSt" action="{{ isset($service_contract)? route('service_contract.update', $service_contract->id) : '' }}" enctype="multipart/form-data">
              @csrf
                <div class="row">
                    <div class="form-group col-md-12">
                        <label>Contract Description</label>
                        <textarea name="contract_description" class="form-control" id="" cols="30" rows="10">{{ isset($service_contract) ? $service_contract->description : ''}}</textarea>
                    </div>
                    <div class="form-group col-md-4">
                        <label>Contract Cost</label>
                        <input type="text" name="contract_cost" value="{{ isset($service_contract) ? $service_contract->amount : ''}}" id="contractCost" class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Frequency Of Pay</label>
                        <input type="text" name="frequency_of_pay" value="{{ isset($service_contract) ? $service_contract->frequency_of_pay : ''}}" id="frequencyOFPay" class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Upload Invoice</label>
                        <input type="file" name="image" class="form-control">
                        @if(isset($service_contract->image) && !empty($service_contract->image))
                            <a class="mt-3"  href="{{asset('public/admin/assets/img/servicecontract/'.$service_contract->image)}}" target="_blank">View Invoice</a>
                        @endif 
                    </div>
                    </div>
                    <div class="row">
                    <div class="form-group col-md-4">
                        <label>Renew date</label>
                        <input type="text" name="renew_date" value="{{ isset($service_contract) ? $service_contract->renew_date : ''}}" class="form-control datepicker">
                    </div>
                </div>
               
                <button class="btn btn-primary mr-1" type="submit">Save</button>
                </div>
            </from>
          </div>
</section>    
@stop
@section('footer_scripts')
<script src="{{asset('public/admin/assets/bundles/bootstrap-daterangepicker/daterangepicker.js') }}"></script>
<script>
    (function($) {
            $.fn.inputFilter = function(inputFilter) {
                return this.on("input keydown keyup mousedown mouseup select contextmenu drop", function() {
                if (inputFilter(this.value)) {
                    this.oldValue = this.value;
                    this.oldSelectionStart = this.selectionStart;
                    this.oldSelectionEnd = this.selectionEnd;
                } else if (this.hasOwnProperty("oldValue")) {
                    this.value = this.oldValue;
                    this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
                } else {
                    this.value = "";
                }
                });
            };
        }(jQuery));
    
        
        $("#contractCost").inputFilter(function(value) {
        return /^-?\d*$/.test(value); });
    
        $("#frequencyOFPay").inputFilter(function(value) {
        return /^-?\d*$/.test(value); });
    
    
        
    </script>
@stop