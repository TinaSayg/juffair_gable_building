<footer class="main-footer">
    <div class=" text-center">
      Copyright  &copy; 2021 All rights reserved by SayG SPC,<a href="https://www.sayg.bh">www.sayg.bh </a>
    </div>
    <div class="footer-right">
    </div>
  </footer>